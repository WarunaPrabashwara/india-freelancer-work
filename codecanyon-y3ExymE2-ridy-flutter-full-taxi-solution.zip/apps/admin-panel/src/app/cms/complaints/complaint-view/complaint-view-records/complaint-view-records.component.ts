import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-complaint-view-records',
  templateUrl: './complaint-view-records.component.html'
})
export class ComplaintViewRecordsComponent {

}
