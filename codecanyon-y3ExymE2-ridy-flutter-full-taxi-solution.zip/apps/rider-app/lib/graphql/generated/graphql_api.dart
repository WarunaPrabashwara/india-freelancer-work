// GENERATED CODE - DO NOT MODIFY BY HAND
export 'graphql_api.graphql.dart';
